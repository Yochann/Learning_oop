#include <iostream>
using namespace std;

class event
{
  //atributies
  int day,month,year;
  int hour, minutes;
  string name;
  //methods
  public:

  event(string="Brak", int=1, int=1, int=2015, int=12, int=0);
  ~event();
  void load();
  void show();
};