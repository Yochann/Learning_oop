#include <iostream>
#include "event.h"
using namespace std;

int main()
{
  // bez konstuktora:
  event e1;
  // ------------------------------ //
  // z konstukotrem
  //event e1("strajk", 10, 12, 2077, 19, 18);
  // Bez konstruktora pojawi sie to powyzej ^
  // e1.load();
  e1.show();
}