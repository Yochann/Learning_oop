#include <iostream>
#include "event.h"
using namespace std;

void event::load()
{
  cout<<endl<<"Podaj nazwe wydarzenia: ";
  cin>>name;
  cout<<endl<<"Podaj dzień: ";
  cin>>day;
  cout<<endl<<"Podaj miesiac ";
  cin>>month;
  cout<<endl<<"Podaj rok ";
  cin>>year;
  cout<<endl<<"Podaj godzine: ";
  cin>>hour;
  cout<<endl<<"Podaj minute: ";
  cin>>minutes;
}

void event::show()
{
  cout<<"Wydarzenie o nazwie: "<<name<<" odbedzie się dnia: "<<day<<".";
  if(month<=9) cout<<0<<month;
  else cout<<month;
  cout<<"."<<year<<endl;
  cout<<"O godzinie: "<<hour<<":";
  if(minutes<=9) cout<<0<<minutes;
  else cout <<minutes;
}

// konstruktor
event::event(string n, int d, int mo, int y, int h, int mi)
//event:event(string n="Brak", int d=1, int mo=1, int y=2015, int h=12, int mi="00")
{
  name=n;
  day=d;
  month=mo;
  year=y;
  hour=h;
  minutes=mi;
}

event::~event()
{
  cout<<endl<<"Dodano wydarzenie!";
}