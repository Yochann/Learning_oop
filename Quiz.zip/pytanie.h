#include <iostream>
using namespace std;

class pytanie
{
  public:
  string tresc;
  string a,b,c,d;
  string poprawna;
  string odpowiedz;
  int numer_pytania;
  int punkt; //score 1 lub 0 

  // methods
  void wczytaj(); // wczytuje pytania z pliku txt
  void zadaj_pytanie(); // zadje pytanie
  void sprawdz(); // sprawdza czy udzielona odpowiedź jest poprawna
};