#include <iostream>
#include "pytanie.h"

using namespace std;

int main() 
{
  int sum=0;
  pytanie p[5];
  for(int i=0; i<=4; i++)
  {
    p[i].numer_pytania=i+1;
    p[i].wczytaj();
    p[i].zadaj_pytanie();
    p[i].sprawdz();
    cout <<endl<<"Punkty: "<<p[i].punkt;
    sum+=p[i].punkt;
  }
  cout<<endl<<"KONIEC QUIZU"<<endl<<" TWOEJ PUNKTY: "<<sum;
  return 0;
}