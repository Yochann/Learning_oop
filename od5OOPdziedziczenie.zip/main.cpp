#include <iostream>
#include <math.h>
using namespace std;

class punkt
{
  float x,y;
  string nazwa;

  public:
  void wyswietl()
  {
    cout<<nazwa<<"("<<x<<","<<y<<")"<<endl;
  }
  punkt(string n="S", float a=0, float b=0)
  {
    nazwa=n;
    x=a;
    y=b;
  }
};

// klasa kolo dziedziczy publicznie (bez zmian) z klasy punkt
class kolo :public punkt
{
  float r;
  string nazwa;

  public:
  //methods
  void wyswietl()
  {
    cout<<"kolo o nazwie: "<<nazwa<<endl;
    cout<<"srodek kola: ";
    punkt::wyswietl();
    cout<<"promien: "<<r<<endl;
    cout<<"pole kola: "<<M_PI*r*r<<endl;
  }
  kolo(string nk="kolko", string np="S", float a=0, float b=0, float pr=1)
  :punkt(np,a,b)
  {
    nazwa= nk;
    r= pr;
  }
}; 


int main() 
{
  kolo k1;
  k1.wyswietl();

  return 0;
}