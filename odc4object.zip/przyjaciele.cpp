#include <iostream>
#include "przyjaciele.h"
using namespace std;

punkt::punkt(string n, float xx, float yy)
{
  nazwa=n;
  x=xx;
  y=yy;
}

void punkt::wczytaj()
{
  cout<<"podaj x: "; cin>>x;
  cout<<"podaj y: "; cin>>y;
  cout<<"Podaj nazwe punktu: "; cin>>nazwa;
}

prostokat::prostokat(string n, float xx, float yy, float sz, float wy)
{
  nazwa=n;
  x=xx;
  y=yy;
  szerokosc=sz;
  wysokosc=wy;
}

void prostokat::wczytaj()
{
  cout<<"podaj nazwe lewego dolnego punktu prostokata: "; cin>>nazwa;
  cout<<"podaj x lewego dolnego punktu prostokata: "; cin>>x;
  cout<<"podaj y lewego dolnego punktu prostokata: "; cin>>y;
  cout<<"podaj szerokosc lewego dolnego punktu prostokata: "; cin>>szerokosc;
  cout<<"podaj wysokosc lewego dolnego punktu prostokata: "; cin>>wysokosc;
}