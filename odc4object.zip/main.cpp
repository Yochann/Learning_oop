#include <iostream>
#include "przyjaciele.h"
using namespace std;

void sedzia(punkt &pt, prostokat &p)
{
  if( pt.x>=p.x && pt.x<=p.x+p.szerokosc &&
      pt.y>=p.y && pt.y<=p.y+p.wysokosc )
  {
    cout<<endl<<"Punkt '"<<pt.nazwa<<"' znajduje sie W prostokacie "<<p.nazwa;
  }
  else cout<<endl<<"Punkt '"<<pt.nazwa<<"' znajduje sie POZA prostokacie "<<p.nazwa;
}


int main() 
{
  //punkt pt1("A", 3 , 1);
  pt1.wczytaj();
  //prostokat p1("prostokat", 0, 0, 6, 4);
  p1.wczytaj();
  sedzia(pt1, p1);

}


// note: uppersanty powoduje ze nie sa tworzone kopie ale przesyłane są oryginały do funkcji 