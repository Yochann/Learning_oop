#include <iostream>
using namespace std;

class samochod
{
  public:
  //atrybuty
  string marka;
  string model;
  int rocznik;
  int przebieg;
  //methods
  void wczytaj()
  {
    cout<<"Yolo ziomuś podaj marke swojego brum burm: "<<endl;
    cin>>marka;
    cout<<"To może jeszcze model poprosze: "<<endl;
    cin>>model;
    cout<<"A to jeszcze rocznik i przebieg"<<endl;
    cin>>rocznik>>przebieg;
  }
  void wypisz()
  {
    cout<<"Samochód marki: "<<marka<<"model: "<<model<<" robi brum brum"<<endl;
    cout <<"Rocznik: "<<rocznik;
    cout <<"Przebieg wynosi: "<<przebieg;
  }
};

int main() 
{
  samochod tesla;
  tesla.wczytaj();
  tesla.wypisz();
  return 0;
}