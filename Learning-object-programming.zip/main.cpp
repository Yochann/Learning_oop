#include <iostream>
using namespace std;
class zwierze
{
  public:
    // atributes
    string gatunek;
    string imie;
    int wiek;

    // Methods
    void dodaj_zwierze()
    {
      cout<<"Podaj gatunek"<<endl;
      cin>>gatunek;
      cout<<"Podaj imie"<<endl;
      cin>>imie;
      cout<<"Podaj wiek"<<endl;
      cin>>wiek;
    }
    void dodaj_glos()
    {
      if(gatunek=="kot") cout<<imie<<" lat:"<<wiek<<" "<<":Miauu!";
      else if(gatunek=="koza") cout<<imie<<" lat:"<<wiek<<" "<<":Beee!";
      else if(gatunek=="krowa") cout<<imie<<" lat:"<<wiek<<" "<<":Muuu!";
      else cout<<"nieznany gatunek o.o";
    }
};


int main() 
{ // zwierze z1 => int x;
    zwierze z1;
    z1.dodaj_zwierze();
    z1.dodaj_glos();
}